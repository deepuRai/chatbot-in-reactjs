
import React from 'react';

const ItemList = () => (
    <div>
        <h1>Here goes a list of items</h1>
    </div>
)

export default ItemList;