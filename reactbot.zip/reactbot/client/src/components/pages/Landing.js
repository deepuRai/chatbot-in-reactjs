import React from 'react';

const Landing = () => (
    <div style={{ textAlign: 'center' }}>
        <h1>Selling you great stuff!</h1>
        with the help of the chatbot
    </div>
)

export default Landing;